Robotypo
	http://robotypo.appspot.com/
	
A competition platform for robots - special Java programs.

This package is the Eclipse project for setting up Robotypo debugging environment. 
It's easier to create robots in Eclipse than using the web site anyway.

You can import this archive directly into Eclipse (No need to extract). Follow the guide here: 
	http://robotypo.appspot.com/all/setupDebugEnv.html

To start debugging, run the "Test.java", in myrobotypo.drunkard or myrobotypo.fruitday.

The source file for the core (rule engines) are also packaged within the jar file. 

Visit: 
	http://robotypo.appspot.com/ 

----------------------------------------------

By Verilocos, a coder who likes fun stuff.
verilocos@gmail.com

