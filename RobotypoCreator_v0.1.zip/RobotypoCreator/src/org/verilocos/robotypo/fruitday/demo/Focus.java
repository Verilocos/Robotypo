package org.verilocos.robotypo.fruitday.demo;

import org.verilocos.robotypo.fruitday.Fruitday;

/**
 * With the robot "Focus", all peasants in our team hit one 
 * opponent peasant intensively, so it will be out-of-play 
 * quickly. That's good for us.
 */
public class Focus extends Fruitday {

	int focus;	//A member variable which stores our focus
	
	public void strategy() {

		//Get the opponent peasant at our focus
		Peasant p = opponentTeam[focus];
		
		//If it is out-of-play...
		if (p.hp == 0 	 
				//OR: (we are smart) if it's hiding in the previous round...
				|| p.action == HIDE) {	//(The p.action stores the action of the peasant in the PREVIOUS round) 
			
			//Move the focus to the next one.
			if (++focus > 2)
				focus = 0;	
		}
		
		//Set actions: "All fire at the focus!"
		for (int i = 0; i < 3; i++)
			myTeam[i].action = focus;
	}
}
