package org.verilocos.robotypo.fruitday.demo;

import org.verilocos.robotypo.fruitday.Fruitday;

/**
 * The robot Focus is good. However it's too predictable. 
 * Let's defeat it, simply, and *perfectly*.
 */
public class FocusKiller extends Fruitday {

	int focus;
	
	public void strategy() {

		//Move focus.
		if (++focus > 2)
			focus = 0;

		for (int i = 0; i < 3; i++)
			//If I'm at opponent's focus, I hide, otherwise I hit.
			myTeam[i].action = i == focus ? HIDE : focus;
	}
}
