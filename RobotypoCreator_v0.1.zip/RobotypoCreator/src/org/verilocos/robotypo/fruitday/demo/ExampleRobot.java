package org.verilocos.robotypo.fruitday.demo;

import org.verilocos.robotypo.fruitday.Fruitday;

/**
 * Fruitday robot example.
 */
public class ExampleRobot extends Fruitday {
	
	/**
	 * Set the hit or hide strategy for each peasant in our team. 
	 * This method is called before each round.
	 */
	public void strategy() {
		
        for (int i = 0; i < 3; i++) { //for each member in our team

            Peasant p = myTeam[i];

            //Target at a random member (0, 1, or 2) in opponent team. "The brave never hides!"
            p.action = random.nextInt(3); 

            //Alternatively, you can choose to hide like this:
            //p.action = HIDE;
        }
        
        //The following member variables can be used, too:
        //		int round        
        //		Peasant[] opponentTeam 
        //"round" stores the current round number.
        //"opponentTeam" stores the three members in the opponent team. You can read 
        //their current HP, and the action of the previous round.
        //Note that before you set action in this method, the member variable "myTeam" is 
        //unchanged as in the previous round. So you do not need to create additional 
        //variables to record your actions and HPs of the previous round. 
        
        //For more details, refer to help.
	}
	
	/* Create member variables if needed: */
	//int myVar = 0;
	//int[] myData = {0, 1, 3};
	//List myList = new ArrayList();
	
	/* The Java class initialization block.  */
	{
		/*	Do first-time initialization here if needed. For example:*/
		
		//	for (int i = 0; i < 3; i++) {
		//		some logic...
		//	}
	}
	
	/* Add custom functions if needed: */
	
	//int function f() {
	//		return 0;
	//}
}
