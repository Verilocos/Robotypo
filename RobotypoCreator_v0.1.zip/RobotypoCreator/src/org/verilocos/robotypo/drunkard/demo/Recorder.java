package org.verilocos.robotypo.drunkard.demo;
import org.verilocos.robotypo.drunkard.Drunkard;

/**
 * This robot analyzes action of opponent in the previous round.
 * For some robots, it is likely that it will raise the same
 * finger count, and/or make the same guess as previous rounds.
 * We read that info, and adjust our strategy.
 */
public class Recorder extends Drunkard {

	public void strategy() {

		// My finger count that guessed by opponent in the previous round
		int opponentGuessed = prevOpponentSum - prevOpponentFingers;
    	
		// If my finger count matches opponent guess...
		while (fingers == opponentGuessed)
			//change my finger count.
			if (++fingers > 5)
				fingers = 0;
        
		//Guess opponent raises the same finger count as the previous round. 
		sum = fingers + prevOpponentFingers;
    }
}