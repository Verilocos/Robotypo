package org.verilocos.robotypo.drunkard.demo;
import org.verilocos.robotypo.drunkard.Drunkard;

/**
 * The FullHand robot takes advantage of the "Full Hand" rule:
 * when both sides guess of the sum correctly, the drunkard 
 * who raises 5 fingers wins the round.
 */
public class FullHand extends Drunkard {

    public void strategy() {
        fingers = 5;	//Always raise 5 fingers
        sum = 5 + random.nextInt(6);	//Make a random guess
    }
}