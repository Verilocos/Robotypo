package org.verilocos.robotypo.drunkard.demo;

import org.verilocos.robotypo.drunkard.Drunkard;

/**
 * Drunkard robot example.
 */
public class ExampleRobot extends Drunkard {
	
	/**
	 * Raise our fingers and guess the total sum. 
	 * This method is called before each round.
	 */
	public void strategy() {
		//First we need to set the number of fingers we raise. 
		//There are only 5 fingers per human hand. So the finger count 
		//must be 0, 1, 2, 3, 4, or 5.		
		fingers = round % 6;	//"round" indicates the current round number. In this example we are making this pattern: 0, 1, 2, 3, 4, 5, 0, 1, ...  

		//"sum" is the total finger count (sum of fingers from both drunkards). It is a number "we say".
		//At the end of this round, anyone who guessed the correct sum 
		//wins (if opponent guesses incorrectly).
		sum = fingers + random.nextInt(6);	//Let's make a random guess.
				
		//The following members store the value of the previous round. They are helpful
		//to analysis opponent's strategy. Note that before you set "fingers" & "sum",
		//they remain the same as in the previous round. So you can get "my strategy" of 
		//the previous round as well:
		//		prevOpponentSum
		//		prevOpponentFingers
		//		fingers
		//		sum
		
		//For more details, refer to help.
	}
	
	/* Create member variables if needed: */
	//int myVar = 0;
	//int[] myData = {0, 1, 3};
	//List myList = new ArrayList();
	
	/* The Java class initialization block.  */
	{
		/*	Do first-time initialization here if needed. For example:*/
		
		//	for (int i = 0; i < 3; i++) {
		//		some logic...
		//	}
	}
	
	/*	Add custom functions if needed: */
	//int function f() {
	//		return 0;
	//}
}
