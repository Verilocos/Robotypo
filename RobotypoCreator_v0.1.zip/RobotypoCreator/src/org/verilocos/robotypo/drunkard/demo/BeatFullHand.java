package org.verilocos.robotypo.drunkard.demo;
import org.verilocos.robotypo.drunkard.Drunkard;

/**
 * Beat the robot FullHand perfectly.
 */
public class BeatFullHand extends Drunkard {

    public void strategy() {
        fingers = 0;
        sum = 5;
    }
}