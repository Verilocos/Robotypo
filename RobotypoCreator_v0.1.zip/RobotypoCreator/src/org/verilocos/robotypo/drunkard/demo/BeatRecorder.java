package org.verilocos.robotypo.drunkard.demo;
import org.verilocos.robotypo.drunkard.Drunkard;

/**
 * Recorder is good. Let's defeat it simply and perfectly.
 */
public class BeatRecorder extends Drunkard {
	
	public void strategy() {

		if (++fingers > 5)
			fingers = 0;
		sum = fingers * 2;
	}
}