package myrobotypo.fruitday;

import org.verilocos.robotypo.fruitday.Fruitday;

public class MyFirstFruitday extends Fruitday {

	//This is the method called before each round.
	public void strategy() {
		
		for (int i = 0; i < 3; i++) {		//For each peasant in our team,
			Peasant p = myTeam[i];
			p.action = random.nextInt(3);	//hit opponent peasant at a random position.
			
			//You can also tell peasant to hide, like this:
			//p.action = HIDE;
		}
	}
}
