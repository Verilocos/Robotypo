package myrobotypo.fruitday;

import org.verilocos.robotypo.fruitday.FruitdayTester;
import org.verilocos.robotypo.fruitday.demo.*;

public class Test {

	public static void main(String[] args) {
		
		//Start a fight between the two robots.
		FruitdayTester.test(MyFirstFruitday.class, Focus.class);
		
		//FruitdayTester.test(FocusKiller.class, Focus.class);
		
		//Alternatively, test multiple times, silently
		//FruitdayTester.test(MyFirstFruitday.class, Focus.class, 1000);
	}
}
