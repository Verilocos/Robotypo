package myrobotypo.fruitday;

import org.verilocos.robotypo.fruitday.Fruitday;
import org.verilocos.robotypo.fruitday.FruitdayTester;
import org.verilocos.robotypo.fruitday.demo.*;

public class Test {

	public static void main(String[] args) {
		
		Class<? extends Fruitday> robot1 = MyFirstFruitday.class;
		//Class<? extends Fruitday> robot1 = FocusKiller.class;
		
		Class<? extends Fruitday> robot2 = Focus.class;
		
		//Start a fight between the two robots.
		FruitdayTester.test(robot1, robot2);
		
		//Alternatively, test multiple times, silently
		//FruitdayTester.test(robot1, robot2, 1000);
	}
}
