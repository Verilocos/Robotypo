package myrobotypo.drunkard;

import org.verilocos.robotypo.drunkard.DrunkardTester;
import org.verilocos.robotypo.drunkard.demo.*;

public class Test {

	public static void main(String[] args) {
		
		//Start a fight between the two robots.
		DrunkardTester.test(MyFirstDrunkard.class, Recorder.class);
		
		//DrunkardTester.test(BeatRecorder.class, Recorder.class);
		//DrunkardTester.test(MyFirstDrunkard.class, FullHand.class);
		//DrunkardTester.test(FullHand.class, BeatRecorder.class);
		//DrunkardTester.test(Recorder.class, FullHand.class);
		//DrunkardTester.test(BeatFullHand.class, FullHand.class);
		
		//Alternatively, test multiple times, silently
		//DrunkardTester.test(MyFirstDrunkard.class, Recorder.class, 1000);
	}
}
