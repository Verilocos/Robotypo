package myrobotypo.drunkard;

import org.verilocos.robotypo.drunkard.Drunkard;
import org.verilocos.robotypo.drunkard.DrunkardTester;
import org.verilocos.robotypo.drunkard.demo.*;

public class Test {

	public static void main(String[] args) {
		
		Class<? extends Drunkard> robot1 = MyFirstDrunkard.class;
		//Class<? extends Drunkard> robot1 = BeatFullHand.class;
		//Class<? extends Drunkard> robot1 = BeatRecorder.class;
		
		//Class<? extends Drunkard> robot2 = FullHand.class;
		Class<? extends Drunkard> robot2 = Recorder.class;
		
		//Start a fight between the two robots.
		DrunkardTester.test(robot1, robot2);
		
		//Alternatively, test multiple times, silently
		//DrunkardTester.test(robot1, robot2, 1000);
	}
}
