package myrobotypo.drunkard;

import org.verilocos.robotypo.drunkard.Drunkard;

public class MyFirstDrunkard extends Drunkard {

    //This method is called before a round. Set our strategy here.
    public void strategy() {
    	
        fingers = 3;					//Raise some fingers (0 to 5). Here we always raise 3.
        sum = 3 + random.nextInt(6);	//The total number we guess.
    }
}
